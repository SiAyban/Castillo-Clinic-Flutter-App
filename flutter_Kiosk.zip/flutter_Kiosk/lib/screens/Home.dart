import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Children\'s Clinic',
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          
          Positioned.fill(
            child: Image.asset(
              'assets/APPS.png',
              fit: BoxFit.cover,
            ),
          ),

          
          Align(
            alignment: Alignment(-0.1, -0.3), 
            child: BubbleButton(
              text: 'Clinic Records',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ClinicRecordsPage()),
                );
              },
            ),
          ),
          Align(
            alignment: Alignment(-0.6, 0.1), 
            child: BubbleButton(
              text: 'Get QR Code',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => QRCodePage()),
                );
              },
            ),
          ),
          Align(
            alignment: Alignment(-0.1, 0.5), 
            child: BubbleButton(
              text: 'Logout',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LogoutPage()),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class BubbleButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const BubbleButton({
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 120,
        height: 120,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          image: DecorationImage(
            image: AssetImage('assets/bubbleButtons.png'), 
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
              color: Colors.black,
              shadows: [
                Shadow(
                  blurRadius: 2,
                  color: Colors.white,
                  offset: Offset(1, 1),
                ),
              ],
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}


class ClinicRecordsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Clinic Records'),
      ),
      body: Center(
        child: Text(
          'This is the Clinic Records page',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}

class QRCodePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('QR Code'),
      ),
      body: Center(
        child: Text(
          'This is the QR Code page',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}

class LogoutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Logout'),
      ),
      body: Center(
        child: Text(
          'You have been logged out',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
