import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ClinicRecordsPage extends StatelessWidget {
  final String email; // Pass the logged-in user's email

  const ClinicRecordsPage({super.key, required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/latestBG1.png',
              fit: BoxFit.cover,
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 30.0),
              child: Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.6,
                  width: MediaQuery.of(context).size.width * 0.9,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black,
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back),
                            onPressed: () => Navigator.pop(context),
                          ),
                          const SizedBox(width: 4),
                          const Text(
                            'Clinic Records',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.teal,
                            ),
                          ),
                        ],
                      ),
                      const Divider(thickness: 1),
                      Expanded(
                        child: StreamBuilder<QuerySnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('clinic_records')
                              .where('email', isEqualTo: email)
                              .snapshots(),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const Center(child: CircularProgressIndicator());
                            }

                            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                              return const Center(child: Text('No records found.'));
                            }

                            final records = snapshot.data!.docs;

                            return ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              itemCount: records.length,
                              itemBuilder: (context, index) {
                                final record = records[index].data() as Map<String, dynamic>;
                                return GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => RecordDetailsPage(record: record),
                                      ),
                                    );
                                  },
                                  child: Card(
                                    margin: const EdgeInsets.symmetric(vertical: 6),
                                    elevation: 2,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(10),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            record['name'] ?? 'Unknown',
                                            style: const TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text('Diagnosis: ${record['diagnosis'] ?? ''}', style: const TextStyle(fontSize: 14)),
                                          Text('Date: ${record['date'] ?? ''}', style: const TextStyle(fontSize: 14)),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RecordDetailsPage extends StatelessWidget {
  final Map<String, dynamic> record;

  const RecordDetailsPage({super.key, required this.record});

  String getBmiStatus(String bmiStr) {
    double bmi = double.tryParse(bmiStr) ?? 0;
    if (bmi < 14) {
      return 'Underweight';
    } else if (bmi >= 14 && bmi <= 18) {
      return 'Normal';
    } else {
      return 'Overweight';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/latestBG1.png',
              fit: BoxFit.cover,
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 30.0),
              child: Center(
                child: SingleChildScrollView(
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.9,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black,
                          blurRadius: 6,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              onPressed: () => Navigator.pop(context),
                            ),
                            const SizedBox(width: 4),
                            const Text(
                              'Clinic Record Details',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.teal,
                              ),
                            ),
                          ],
                        ),
                        const Divider(thickness: 1),
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              buildRecordRow('Patient Name:', record['name'] ?? 'N/A'),
                              const SizedBox(height: 10),
                              buildRecordRow('Age:', record['age']?.toString() ?? 'N/A'), // Convert age to string safely
                              const SizedBox(height: 10),
                              buildRecordRow('Diagnosis:', record['diagnosis'] ?? 'N/A'),
                              const SizedBox(height: 10),
                              buildRecordRow('Date:', record['date'] ?? 'N/A'),
                              const SizedBox(height: 20),
                              const Text(
                                'Kiosk Records',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.teal,
                                ),
                              ),
                              const Divider(thickness: 1),
                              const SizedBox(height: 10),
                              buildRecordRow('Height:', record['height'] ?? 'N/A'),
                              const SizedBox(height: 10),
                              buildRecordRow('Weight:', record['weight'] ?? 'N/A'),
                              const SizedBox(height: 10),
                              buildRecordRow('BMI:', record['bmi'] ?? 'N/A'),
                              const SizedBox(height: 4),
                              buildRecordRow('BMI Status:', getBmiStatus(record['bmi'] ?? '0')),
                              const SizedBox(height: 10),
                              buildRecordRow('Temperature:', record['temperature'] ?? 'N/A'),
                              const SizedBox(height: 10),
                              buildRecordRow('Heart Rate:', record['heartRate'] ?? 'N/A'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildRecordRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 4,
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
        Expanded(
          flex: 6,
          child: Text(
            value,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }
}
