import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'main.dart'; // To access SplashScreen for logout
import 'clinic_records.dart'; // Import your ClinicRecordsPage file
import 'qr_code.dart'; // Import your QRCodePage file

class HomePage extends StatefulWidget {
  final String email;

  const HomePage({super.key, required this.email});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String userName = '';
  String userId = '';

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('clinic_accounts')
          .where('email', isEqualTo: widget.email)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final data = snapshot.docs.first.data();
        setState(() {
          userName = data['name'] ?? 'Unknown';
          userId = snapshot.docs.first.id;
        });
      } else {
        setState(() {
          userName = 'Unknown';
          userId = 'No ID';
        });
      }
    } catch (e) {
      print('Error fetching user data: $e');
      setState(() {
        userName = 'Error';
        userId = 'Error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/latestBG1.png',
              fit: BoxFit.cover,
            ),
          ),
          Align(
            alignment: const Alignment(-0.3, -0.3), // Moved left
            child: BubbleButton(
              text: 'Clinic Records',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ClinicRecordsPage(email: widget.email),
                  ),
                );
              },
            ),
          ),
          Align(
            alignment: const Alignment(-0.8, 0.1), // Moved left
            child: BubbleButton(
              text: 'Get QR Code',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QRCodePage(
                      email: widget.email,
                      userName: userName,
                      userId: userId,
                    ),
                  ),
                );
              },
            ),
          ),
          Align(
            alignment: const Alignment(-0.3, 0.5), // Moved left
            child: BubbleButton(
              text: 'Logout',
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const SplashScreen()),
                  (route) => false,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class BubbleButton extends StatefulWidget {
  final String text;
  final VoidCallback onTap;

  const BubbleButton({
    super.key,
    required this.text,
    required this.onTap,
  });

  @override
  State<BubbleButton> createState() => _BubbleButtonState();
}

class _BubbleButtonState extends State<BubbleButton> {
  double _scale = 1.0;

  void _updateScale(bool active) {
    setState(() {
      _scale = active ? 1.1 : 1.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => _updateScale(true),
      onExit: (_) => _updateScale(false),
      child: GestureDetector(
        onTap: widget.onTap,
        onTapDown: (_) => _updateScale(true),
        onTapUp: (_) => _updateScale(false),
        onTapCancel: () => _updateScale(false),
        child: AnimatedScale(
          scale: _scale,
          duration: const Duration(milliseconds: 150),
          child: Container(
            width: 120,
            height: 120,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(
                image: AssetImage('assets/bubbleButtons.png'),
                fit: BoxFit.cover,
              ),
            ),
            child: Center(
              child: Text(
                widget.text,
                style: const TextStyle(
                  fontFamily: 'WorkSans', // 👈 added your Work Sans font here
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Colors.black,
                  shadows: [
                    Shadow(
                      blurRadius: 2,
                      color: Colors.white,
                      offset: Offset(1, 1),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
